<?php
$conn =  mysqli_connect('localhost','empresspack_delipaperuser','DeliPaperSecurePassword!','empresspack_delipaperdb');
?>