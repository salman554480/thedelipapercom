<?php require_once('parts/top.php'); ?>

</head>

<body>
    <?php require_once('parts/navbar.php'); ?>
    <div class="website-area">
        <div class="w-90 py-5 ">
            <h1 class="section-heading text-center">Terms & Conditions</h1>
            <div class="row my-3">
                <div class="col-md-12"></div>


            </div>
        </div>

    </div>




    <?php require_once('parts/footer.php'); ?>